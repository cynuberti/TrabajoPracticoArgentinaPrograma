import logo from './logo.svg';
import './App.css';
import Container from './componentes/Container.js';

function App() {
  return (
    <div className="App">
      <Container />
    </div>
  );
}

export default App;
